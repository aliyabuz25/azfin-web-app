
import React, { createContext, useContext, useState, useEffect } from 'react';
import { SERVICES, STATISTICS, BLOG_POSTS, TRAININGS } from '../constants';
import { ServiceItem, StatisticItem, BlogItem, TrainingItem, SiteSettings, SectorItem, ProcessStep, Application } from '../types';
import { getIcon } from '../utils/icons';

interface DataContextType {
    services: ServiceItem[];
    statistics: StatisticItem[];
    blogs: BlogItem[];
    trainings: TrainingItem[];
    processSteps: ProcessStep[];
    siteSettings: SiteSettings;
    applications: Application[];

    // CRUD Actions
    addService: (item: any) => void;
    updateService: (id: string, item: any) => void;
    deleteService: (id: string) => void;

    addBlog: (item: any) => void;
    updateBlog: (id: string, item: any) => void;
    deleteBlog: (id: string) => void;

    addTraining: (item: any) => void;
    updateTraining: (id: string, item: any) => void;
    deleteTraining: (id: string) => void;

    addSector: (item: any) => void;
    updateSector: (id: string, item: any) => void;
    deleteSector: (id: string) => void;

    addProcessStep: (item: any) => void;
    updateProcessStep: (id: string, item: any) => void;
    deleteProcessStep: (id: string) => void;

    addStatistic: (item: any) => void;
    updateStatistic: (id: string, item: any) => void;
    deleteStatistic: (id: string) => void;

    addApplication: (type: Application['type'], data: any) => void;
    deleteApplication: (id: string) => void;
    updateApplicationStatus: (id: string, status: Application['status']) => void;

    updateSiteSettings: (settings: SiteSettings) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

const DEFAULT_SETTINGS: SiteSettings = {
    phoneNumber: '+994 50 200 00 00',
    email: 'office@azfin.az',
    address: 'Bakı, Azərbaycan',
    workingHours: 'B.e - Cümə: 09:00 - 18:00',
    heroTitle: 'Biznesiniz üçün Professional Audit',
    heroSubtitle: 'Azfin Consulting olaraq şirkətlərin maliyyə hesabatlılığında şəffaflığı təmin edir, vergi risklərini minimuma endirir və strateji inkişaf yollarını müəyyən edirik.',
    heroBadge: 'Lisenziyalı Audit Xidmətləri',
    heroImage: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=1000',
    heroButtonText: 'Xidmətlər',
    heroButtonLink: '/services',
    ctaTitle: 'AUDİT TƏKLİFİ AL',
    ctaButtonText: 'MÜRACİƏT ET',
    ctaButtonLink: '/contact',
    instagramUrl: 'https://instagram.com/azfin',
    linkedinUrl: 'https://linkedin.com/company/azfin',
    facebookUrl: 'https://facebook.com/azfin',
    whatsappNumber: '994502000000',
    messengerUsername: 'azfin',
    navbarButtonText: 'ƏLAQƏ',
    navbarButtonLink: '/contact',
    footerDescription: 'Azərbaycanın ən innovativ audit və konsalting mərkəzi. Biznesinizin maliyyə gələcəyini beynəlxalq güclə quraq.',
    footerText: '© 2024 Azfin Consulting. Bütün hüquqlar qorunur.',
    homeServicesTitle: 'Əsas Xidmətlərimiz',
    homeServicesSubtitle: 'Professional Həllər',
    homeSectorsTitle: 'Konsalting Sahəsində Bir Çox Sektor Üzrə Peşəkarıq',
    homeProcessTitle: 'İş Prosesimiz',
    homeProcessSubtitle: 'Hər bir layihəyə elmi əsaslarla və beynəlxalq audit metodologiyası ilə yanaşırıq.',
    homeClientsTitle: 'BİZƏ GÜVƏNƏN MÜŞTƏRİLƏRİMİZ',
    contactTitle: 'Bizimlə Əlaqə',
    contactSubtitle: 'Suallarınız var? Bizə yazın və peşəkar komandamız sizə ən qısa zamanda cavab versin.'
};

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [services, setServices] = useState<ServiceItem[]>([]);
    const [statistics, setStatistics] = useState<StatisticItem[]>([]);
    const [blogs, setBlogs] = useState<BlogItem[]>([]);
    const [trainings, setTrainings] = useState<TrainingItem[]>([]);
    const [sectors, setSectors] = useState<SectorItem[]>([]);
    const [processSteps, setProcessSteps] = useState<ProcessStep[]>([]);
    const [siteSettings, setSiteSettings] = useState<SiteSettings>(DEFAULT_SETTINGS);
    const [applications, setApplications] = useState<Application[]>([]);
    const [isLoaded, setIsLoaded] = useState(false);

    useEffect(() => {
        const loadData = () => {
            const storedServices = localStorage.getItem('azfin_services');
            const storedStats = localStorage.getItem('azfin_stats');
            const storedBlogs = localStorage.getItem('azfin_blogs');
            const storedTrainings = localStorage.getItem('azfin_trainings');
            const storedSectors = localStorage.getItem('azfin_sectors');
            const storedProcess = localStorage.getItem('azfin_process');
            const storedSettings = localStorage.getItem('azfin_settings');
            const storedApplications = localStorage.getItem('azfin_applications');

            if (storedServices) {
                setServices(enrichServices(JSON.parse(storedServices)));
            } else {
                const initialServices = SERVICES.map(s => ({ ...s, iconName: 'Briefcase' }));
                setServices(initialServices);
                saveData('azfin_services', initialServices);
            }

            if (storedStats) {
                setStatistics(enrichStats(JSON.parse(storedStats)));
            } else {
                const initialStats = STATISTICS.map(s => ({ ...s, iconName: 'Award' }));
                setStatistics(initialStats);
                saveData('azfin_stats', initialStats);
            }

            if (storedBlogs) {
                setBlogs(JSON.parse(storedBlogs));
            } else {
                setBlogs(BLOG_POSTS);
                saveData('azfin_blogs', BLOG_POSTS);
            }

            if (storedTrainings) {
                setTrainings(JSON.parse(storedTrainings));
            } else {
                setTrainings(TRAININGS);
                saveData('azfin_trainings', TRAININGS);
            }

            if (storedSectors) {
                setSectors(JSON.parse(storedSectors));
            } else {
                const initialSectors = [
                    { id: '1', iconName: 'Plane', title: "Logistika və Nəqliyyat", description: "Beynəlxalq daşımalar və tədarük zənciri üzrə maliyyə auditi və strateji planlama." },
                    { id: '2', iconName: 'Utensils', title: "İaşə", description: "Restoran şəbəkələri və qida xidmətləri sektoru üçün xərclərin optimallaşdırılması və vergi uçotu." },
                    { id: '3', iconName: 'GraduationCap', title: "Təhsil", description: "Özəl təhsil müəssisələri və təlim mərkəzlərə üçün maliyyə idarəetməsi və audit xidmətləri." }
                ];
                setSectors(initialSectors);
                saveData('azfin_sectors', initialSectors);
            }

            if (storedProcess) {
                setProcessSteps(JSON.parse(storedProcess));
            } else {
                const initialProcess = [
                    { id: '1', stepNumber: '01', iconName: 'Search', title: "Diaqnostika", description: "Biznesin cari vəziyyətinin dərindən analizi." },
                    { id: '2', stepNumber: '02', iconName: 'Lightbulb', title: "Strategiya", description: "Mümkün risklərin və həll yollarının planlanması." },
                    { id: '3', stepNumber: '03', iconName: 'Rocket', title: "İcraat", description: "Müasir texnoloji alətlərlə auditin həyata keçirilməsi." },
                    { id: '4', stepNumber: '04', iconName: 'ShieldCheck', title: "Təsdiqləmə", description: "Yekun rəy və gələcək inkişaf tövsiyələri." }
                ];
                setProcessSteps(initialProcess);
                saveData('azfin_process', initialProcess);
            }

            if (storedSettings) {
                setSiteSettings(JSON.parse(storedSettings));
            } else {
                setSiteSettings(DEFAULT_SETTINGS);
                localStorage.setItem('azfin_settings', JSON.stringify(DEFAULT_SETTINGS));
            }

            if (storedApplications) {
                setApplications(JSON.parse(storedApplications));
            }

            setIsLoaded(true);
        };

        loadData();
    }, []);

    const enrichServices = (data: any[]): ServiceItem[] => {
        return data.map(item => ({
            ...item,
            icon: getIcon(item.iconName || 'ShieldCheck')
        }));
    };

    const enrichStats = (data: any[]): StatisticItem[] => {
        return data.map(item => ({
            ...item,
            icon: getIcon(item.iconName || 'Award')
        }));
    };

    const saveData = (key: string, data: any[]) => {
        const toSave = data.map(({ icon, ...rest }) => rest);
        localStorage.setItem(key, JSON.stringify(toSave));
    };

    const addService = (item: any) => {
        const newItem = { ...item, id: Date.now().toString(), icon: getIcon(item.iconName) };
        const newServices = [...services, newItem];
        setServices(newServices);
        saveData('azfin_services', newServices);
    };

    const updateService = (id: string, item: any) => {
        const newServices = services.map(s => s.id === id ? { ...item, id, icon: getIcon(item.iconName) } : s);
        setServices(newServices);
        saveData('azfin_services', newServices);
    };

    const deleteService = (id: string) => {
        const newServices = services.filter(s => s.id !== id);
        setServices(newServices);
        saveData('azfin_services', newServices);
    };

    const addBlog = (item: any) => {
        const newItem = { ...item, id: Date.now().toString() };
        const newBlogs = [...blogs, newItem];
        setBlogs(newBlogs);
        saveData('azfin_blogs', newBlogs);
    };

    const updateBlog = (id: string, item: any) => {
        const newBlogs = blogs.map(b => b.id === id ? { ...item, id } : b);
        setBlogs(newBlogs);
        saveData('azfin_blogs', newBlogs);
    };

    const deleteBlog = (id: string) => {
        const newBlogs = blogs.filter(b => b.id !== id);
        setBlogs(newBlogs);
        saveData('azfin_blogs', newBlogs);
    };

    const addTraining = (item: any) => {
        const newItem = { ...item, id: Date.now().toString() };
        const newTrainings = [...trainings, newItem];
        setTrainings(newTrainings);
        saveData('azfin_trainings', newTrainings);
    };

    const updateTraining = (id: string, item: any) => {
        const newTrainings = trainings.map(t => t.id === id ? { ...item, id } : t);
        setTrainings(newTrainings);
        saveData('azfin_trainings', newTrainings);
    };

    const deleteTraining = (id: string) => {
        const newTrainings = trainings.filter(t => t.id !== id);
        setTrainings(newTrainings);
        saveData('azfin_trainings', newTrainings);
    };

    const addSector = (item: any) => {
        const newItem = { ...item, id: Date.now().toString() };
        const newSectors = [...sectors, newItem];
        setSectors(newSectors);
        saveData('azfin_sectors', newSectors);
    };

    const updateSector = (id: string, item: any) => {
        const newSectors = sectors.map(s => s.id === id ? { ...item, id } : s);
        setSectors(newSectors);
        saveData('azfin_sectors', newSectors);
    };

    const deleteSector = (id: string) => {
        const newSectors = sectors.filter(s => s.id !== id);
        setSectors(newSectors);
        saveData('azfin_sectors', newSectors);
    };

    const addProcessStep = (item: any) => {
        const newItem = { ...item, id: Date.now().toString() };
        const newProcess = [...processSteps, newItem];
        setProcessSteps(newProcess);
        saveData('azfin_process', newProcess);
    };

    const updateProcessStep = (id: string, item: any) => {
        const newProcess = processSteps.map(p => p.id === id ? { ...item, id } : p);
        setProcessSteps(newProcess);
        saveData('azfin_process', newProcess);
    };

    const deleteProcessStep = (id: string) => {
        const newProcess = processSteps.filter(p => p.id !== id);
        setProcessSteps(newProcess);
        saveData('azfin_process', newProcess);
    };

    const addStatistic = (item: any) => {
        const newItem = { ...item, id: Date.now().toString(), icon: getIcon(item.iconName) };
        const newStats = [...statistics, newItem];
        setStatistics(newStats);
        saveData('azfin_stats', newStats);
    };

    const updateStatistic = (id: string, item: any) => {
        const newStats = statistics.map(s => s.id === id ? { ...item, id, icon: getIcon(item.iconName) } : s);
        setStatistics(newStats);
        saveData('azfin_stats', newStats);
    };

    const deleteStatistic = (id: string) => {
        const newStats = statistics.filter(s => s.id !== id);
        setStatistics(newStats);
        saveData('azfin_stats', newStats);
    };

    const addApplication = (type: Application['type'], data: any) => {
        const newApp: Application = {
            id: Date.now().toString(),
            type,
            data,
            date: new Date().toLocaleDateString('az-AZ'),
            status: 'new'
        };
        const newApps = [newApp, ...applications];
        setApplications(newApps);
        localStorage.setItem('azfin_applications', JSON.stringify(newApps));
    };

    const deleteApplication = (id: string) => {
        const newApps = applications.filter(a => a.id !== id);
        setApplications(newApps);
        localStorage.setItem('azfin_applications', JSON.stringify(newApps));
    };

    const updateApplicationStatus = (id: string, status: Application['status']) => {
        const newApps = applications.map(a => a.id === id ? { ...a, status } : a);
        setApplications(newApps);
        localStorage.setItem('azfin_applications', JSON.stringify(newApps));
    };

    const updateSiteSettings = (settings: SiteSettings) => {
        setSiteSettings(settings);
        localStorage.setItem('azfin_settings', JSON.stringify(settings));
    };

    if (!isLoaded) return null;

    return (
        <DataContext.Provider value={{
            services, statistics, blogs, trainings, sectors, processSteps, siteSettings,
            addService, updateService, deleteService,
            addBlog, updateBlog, deleteBlog,
            addTraining, updateTraining, deleteTraining,
            addSector, updateSector, deleteSector,
            addProcessStep, updateProcessStep, deleteProcessStep,
            addStatistic, updateStatistic, deleteStatistic,
            applications, addApplication, deleteApplication, updateApplicationStatus,
            updateSiteSettings
        }}>
            {children}
        </DataContext.Provider>
    );
};

export const useData = () => {
    const context = useContext(DataContext);
    if (!context) throw new Error('useData must be used within a DataProvider');
    return context;
};
