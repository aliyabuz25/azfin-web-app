
import React, { useState, useEffect } from 'react';
import AdminLayout from '../../components/admin/Layout';
import ImageUpload from '../../components/admin/ImageUpload';
import { useData } from '../../context/DataContext';
import { Check, Info, Users, MessageSquare, Building2, Plus, Trash2 } from 'lucide-react';

const AboutManager: React.FC = () => {
    const { siteSettings, updateSiteSettings } = useData();

    // For this demonstration, we'll store the about page content in local storage specifically 
    // or extend siteSettings. Let's extend the logic to local storage for more fields.
    const [aboutData, setAboutData] = useState(() => {
        const saved = localStorage.getItem('azfin_about_page');
        return saved ? JSON.parse(saved) : {
            title: 'Azfin Group MMC',
            description: 'Azfin Group MMC 2017-ci ildə təsis edilmişdir. Məqsədimiz Sahibkarlara mühasibatlıqla bağlı məsələlərdə dəstək olmaq və onlara uyğun həll yolları təqdim etmədir.',
            content: 'Hazırda kiçik, orta və iri sahibkarlıq subyektlərinə bütün növ maliyyə, mühasibatlıq, vergi və konsalting xidmətləri göstəririk. Bununla yanaşı müəssisə və fərdi sahibkarların qeydiyyatı, hüquq xidmətləri, audit xidmətləri, tender sənədlərinin hazırlanması, lisenziyaların alınması və konsalting xidmətləri də fəaliyyət sahəmizə daxildir.',
            mission: 'Sahibkarların maliyyə və hüquqi məsələlərdə güvənli tərəfdaşı olmaq, onların inkişafı üçün doğru həlləri tətbiq etmək.',
            scope: 'Mühasibatlıq, audit, vergi, tender sənədləşməsi və hüquqi dəstək üzrə geniş spektrli professional xidmətlər.',
            image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1200',
            team: [
                { id: '1', name: "Elvin Məmmədov", role: "Direktor / Ekspert Auditor", img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400" },
                { id: '2', name: "Leyla Qasımova", role: "Baş Mühasib", img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=400" }
            ],
            testimonials: [
                { id: '1', name: "Arzu Vəliyev", company: "Global Logistics LLC", text: "Azfin Consulting ilə 3 ildir əməkdaşlıq edirik." }
            ]
        };
    });

    const [success, setSuccess] = useState(false);

    const handleSave = () => {
        localStorage.setItem('azfin_about_page', JSON.stringify(aboutData));
        setSuccess(true);
        setTimeout(() => setSuccess(false), 3000);
    };

    const addTeamMember = () => {
        setAboutData({
            ...aboutData,
            team: [...aboutData.team, { id: Date.now().toString(), name: '', role: '', img: '' }]
        });
    };

    const updateTeamMember = (id: string, field: string, value: string) => {
        setAboutData({
            ...aboutData,
            team: aboutData.team.map((m: any) => m.id === id ? { ...m, [field]: value } : m)
        });
    };

    const deleteTeamMember = (id: string) => {
        setAboutData({
            ...aboutData,
            team: aboutData.team.filter((m: any) => m.id !== id)
        });
    };

    return (
        <AdminLayout
            title="Haqqımızda Səhifəsi"
            actions={
                <button onClick={handleSave} className="bg-accent hover:bg-emerald-600 text-white px-8 py-2 rounded-lg font-black text-sm flex items-center gap-2 transition-all shadow-lg shadow-accent/20">
                    <Check className="h-4 w-4" /> {success ? 'Yadda Saxlanıldı' : 'Yadda Saxla'}
                </button>
            }
        >
            <div className="max-w-5xl mx-auto space-y-12 pb-20">
                {/* General Info */}
                <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6">
                    <div className="flex items-center gap-3 pb-4 border-b border-slate-50">
                        <div className="bg-blue-50 p-2 rounded-lg text-blue-500">
                            <Building2 className="h-5 w-5" />
                        </div>
                        <h3 className="text-lg font-black text-slate-800 tracking-tight uppercase">Ümumi Məlumat</h3>
                    </div>

                    <div className="space-y-4">
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Başlıq</label>
                            <input
                                type="text"
                                value={aboutData.title}
                                onChange={e => setAboutData({ ...aboutData, title: e.target.value })}
                                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                            />
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Qısa Təsvir (Vurğulanan)</label>
                            <textarea
                                rows={2}
                                value={aboutData.description}
                                onChange={e => setAboutData({ ...aboutData, description: e.target.value })}
                                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium italic"
                            />
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tam Məzmun</label>
                            <textarea
                                rows={4}
                                value={aboutData.content}
                                onChange={e => setAboutData({ ...aboutData, content: e.target.value })}
                                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                            />
                        </div>
                    </div>
                </div>

                {/* Mission & Scope */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm space-y-4">
                        <h4 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-50 pb-3">Missiyamız</h4>
                        <textarea
                            rows={3}
                            value={aboutData.mission}
                            onChange={e => setAboutData({ ...aboutData, mission: e.target.value })}
                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                        />
                    </div>
                    <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm space-y-4">
                        <h4 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-50 pb-3">Xidmət Sahələrimiz (Təsvir)</h4>
                        <textarea
                            rows={3}
                            value={aboutData.scope}
                            onChange={e => setAboutData({ ...aboutData, scope: e.target.value })}
                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                        />
                    </div>
                </div>

                {/* Team Management */}
                <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6">
                    <div className="flex items-center justify-between pb-4 border-b border-slate-50">
                        <div className="flex items-center gap-3">
                            <div className="bg-purple-50 p-2 rounded-lg text-purple-500">
                                <Users className="h-5 w-5" />
                            </div>
                            <h3 className="text-lg font-black text-slate-800 tracking-tight uppercase">Komandamız</h3>
                        </div>
                        <button onClick={addTeamMember} className="bg-slate-900 text-white px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 hover:bg-slate-800 transition-all">
                            <Plus className="h-4 w-4" /> Əməkdaş Əlavə Et
                        </button>
                    </div>

                    <div className="grid grid-cols-1 gap-6">
                        {aboutData.team.map((member: any) => (
                            <div key={member.id} className="flex flex-col md:flex-row gap-6 p-6 bg-slate-50 rounded-xl border border-slate-100 relative group">
                                <button onClick={() => deleteTeamMember(member.id)} className="absolute top-4 right-4 p-2 text-slate-300 hover:text-red-500 transition-colors">
                                    <Trash2 className="h-4 w-4" />
                                </button>
                                <div className="w-32 h-32 shrink-0">
                                    <ImageUpload
                                        value={member.img}
                                        onChange={url => updateTeamMember(member.id, 'img', url)}
                                        label="Şəkil"
                                    />
                                </div>
                                <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Ad və Soyad</label>
                                        <input
                                            type="text"
                                            value={member.name}
                                            onChange={e => updateTeamMember(member.id, 'name', e.target.value)}
                                            className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Vəzifə</label>
                                        <input
                                            type="text"
                                            value={member.role}
                                            onChange={e => updateTeamMember(member.id, 'role', e.target.value)}
                                            className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </AdminLayout>
    );
};

export default AboutManager;
