
import React, { useState } from 'react';
import AdminLayout from '../../components/admin/Layout';
import ImageUpload from '../../components/admin/ImageUpload';
import { useData } from '../../context/DataContext';
import { Check, Info, Link as LinkIcon, Phone, Mail, MapPin, Clock, FileText, Globe, Share2, MessageCircle, Layout as LayoutIcon } from 'lucide-react';

type TabType = 'general' | 'hero' | 'social' | 'localization';

const SettingsManager: React.FC = () => {
    const { siteSettings, updateSiteSettings } = useData();
    const [formData, setFormData] = useState(siteSettings);
    const [success, setSuccess] = useState(false);
    const [activeTab, setActiveTab] = useState<TabType>('general');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        updateSiteSettings(formData);
        setSuccess(true);
        setTimeout(() => setSuccess(false), 3000);
    };

    const tabs = [
        { id: 'general' as TabType, label: 'Ümumi', icon: Info },
        { id: 'hero' as TabType, label: 'Ana Səhifə (Hero)', icon: LayoutIcon },
        { id: 'social' as TabType, label: 'Sosial və Əlaqə', icon: Share2 },
        { id: 'localization' as TabType, label: 'Mətnlər (Localization)', icon: Globe },
    ];

    return (
        <AdminLayout title="Sayt Tənzimləmələri">
            <div className="max-w-5xl mx-auto">
                <div className="flex flex-wrap gap-2 mb-8 bg-slate-100 p-1 rounded-xl">
                    {tabs.map((tab) => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`flex items-center gap-2 px-6 py-3 rounded-lg text-xs font-black uppercase tracking-widest transition-all ${activeTab === tab.id
                                    ? 'bg-white text-primary shadow-sm'
                                    : 'text-slate-500 hover:text-primary hover:bg-white/50'
                                }`}
                        >
                            <tab.icon className="h-4 w-4" />
                            {tab.label}
                        </button>
                    ))}
                </div>

                <form onSubmit={handleSubmit} className="space-y-8 pb-20">
                    {activeTab === 'general' && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                            <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6">
                                <div className="flex items-center gap-3 pb-4 border-b border-slate-50">
                                    <Info className="h-5 w-5 text-blue-500" />
                                    <h3 className="text-lg font-black text-slate-800 tracking-tight uppercase">Əsas Məlumatlar</h3>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Telefon</label>
                                        <input
                                            type="text"
                                            value={formData.phoneNumber}
                                            onChange={e => setFormData({ ...formData, phoneNumber: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">E-poçt</label>
                                        <input
                                            type="email"
                                            value={formData.email}
                                            onChange={e => setFormData({ ...formData, email: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Ünvan</label>
                                        <input
                                            type="text"
                                            value={formData.address}
                                            onChange={e => setFormData({ ...formData, address: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">İş Saatları</label>
                                        <input
                                            type="text"
                                            value={formData.workingHours}
                                            onChange={e => setFormData({ ...formData, workingHours: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6">
                                <div className="flex items-center gap-3 pb-4 border-b border-slate-50">
                                    <FileText className="h-5 w-5 text-slate-500" />
                                    <h3 className="text-lg font-black text-slate-800 tracking-tight uppercase">Footer və Müəllif Hüquqları</h3>
                                </div>
                                <div className="space-y-4">
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Footer Açıqlama Mətni</label>
                                        <textarea
                                            rows={2}
                                            value={formData.footerDescription}
                                            onChange={e => setFormData({ ...formData, footerDescription: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Copyright Mətni</label>
                                        <input
                                            type="text"
                                            value={formData.footerText}
                                            onChange={e => setFormData({ ...formData, footerText: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === 'hero' && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                            <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6">
                                <div className="flex items-center gap-3 pb-4 border-b border-slate-50">
                                    <LayoutIcon className="h-5 w-5 text-accent" />
                                    <h3 className="text-lg font-black text-slate-800 tracking-tight uppercase">Giriş Bölməsi (Hero Section)</h3>
                                </div>
                                <div className="space-y-4">
                                    <ImageUpload
                                        value={formData.heroImage}
                                        onChange={url => setFormData({ ...formData, heroImage: url })}
                                        label="Hero Şəkli"
                                    />
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Hero Başlıq (HTML dəstəklənir)</label>
                                        <textarea
                                            rows={3}
                                            value={formData.heroTitle}
                                            onChange={e => setFormData({ ...formData, heroTitle: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Hero Badge</label>
                                        <input
                                            type="text"
                                            value={formData.heroBadge}
                                            onChange={e => setFormData({ ...formData, heroBadge: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Hero Alt Başlıq</label>
                                        <textarea
                                            rows={3}
                                            value={formData.heroSubtitle}
                                            onChange={e => setFormData({ ...formData, heroSubtitle: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Buton Mətni</label>
                                            <input
                                                type="text"
                                                value={formData.heroButtonText}
                                                onChange={e => setFormData({ ...formData, heroButtonText: e.target.value })}
                                                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                            />
                                        </div>
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Buton Linki</label>
                                            <input
                                                type="text"
                                                value={formData.heroButtonLink}
                                                onChange={e => setFormData({ ...formData, heroButtonLink: e.target.value })}
                                                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === 'social' && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                            <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6">
                                <div className="flex items-center gap-3 pb-4 border-b border-slate-50">
                                    <Share2 className="h-5 w-5 text-blue-500" />
                                    <h3 className="text-lg font-black text-slate-800 tracking-tight uppercase">Sosial Media Hesabları</h3>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Instagram URL</label>
                                        <input
                                            type="text"
                                            value={formData.instagramUrl}
                                            onChange={e => setFormData({ ...formData, instagramUrl: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">LinkedIn URL</label>
                                        <input
                                            type="text"
                                            value={formData.linkedinUrl}
                                            onChange={e => setFormData({ ...formData, linkedinUrl: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Facebook URL</label>
                                        <input
                                            type="text"
                                            value={formData.facebookUrl}
                                            onChange={e => setFormData({ ...formData, facebookUrl: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6">
                                <div className="flex items-center gap-3 pb-4 border-b border-slate-50">
                                    <MessageCircle className="h-5 w-5 text-emerald-500" />
                                    <h3 className="text-lg font-black text-slate-800 tracking-tight uppercase">Üstü Sürüşən Butonlar (Floating Contact)</h3>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">WhatsApp Nömrəsi (Məs: 994502000000)</label>
                                        <input
                                            type="text"
                                            value={formData.whatsappNumber}
                                            onChange={e => setFormData({ ...formData, whatsappNumber: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Messenger İstifadəçi Adı (Username)</label>
                                        <input
                                            type="text"
                                            value={formData.messengerUsername}
                                            onChange={e => setFormData({ ...formData, messengerUsername: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6">
                                <div className="flex items-center gap-3 pb-4 border-b border-slate-50">
                                    <LinkIcon className="h-5 w-5 text-purple-500" />
                                    <h3 className="text-lg font-black text-slate-800 tracking-tight uppercase">Navbar Butonu</h3>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Navbar Buton Mətni</label>
                                        <input
                                            type="text"
                                            value={formData.navbarButtonText}
                                            onChange={e => setFormData({ ...formData, navbarButtonText: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Navbar Buton Linki</label>
                                        <input
                                            type="text"
                                            value={formData.navbarButtonLink}
                                            onChange={e => setFormData({ ...formData, navbarButtonLink: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === 'localization' && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                            <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6">
                                <div className="flex items-center gap-3 pb-4 border-b border-slate-50">
                                    <Globe className="h-5 w-5 text-emerald-500" />
                                    <h3 className="text-lg font-black text-slate-800 tracking-tight uppercase">Ana Səhifə Mətnləri</h3>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Xidmətlər Başlığı</label>
                                        <input
                                            type="text"
                                            value={formData.homeServicesTitle}
                                            onChange={e => setFormData({ ...formData, homeServicesTitle: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Xidmətlər Alt-başlığı</label>
                                        <input
                                            type="text"
                                            value={formData.homeServicesSubtitle}
                                            onChange={e => setFormData({ ...formData, homeServicesSubtitle: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5 md:col-span-2">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Sektorlar Bölməsi Başlığı</label>
                                        <input
                                            type="text"
                                            value={formData.homeSectorsTitle}
                                            onChange={e => setFormData({ ...formData, homeSectorsTitle: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">İş Prosesi Başlığı</label>
                                        <input
                                            type="text"
                                            value={formData.homeProcessTitle}
                                            onChange={e => setFormData({ ...formData, homeProcessTitle: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">İş Prosesi Alt-başlığı</label>
                                        <input
                                            type="text"
                                            value={formData.homeProcessSubtitle}
                                            onChange={e => setFormData({ ...formData, homeProcessSubtitle: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5 md:col-span-2">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Müştərilər Bölməsi Başlığı</label>
                                        <input
                                            type="text"
                                            value={formData.homeClientsTitle}
                                            onChange={e => setFormData({ ...formData, homeClientsTitle: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6">
                                <div className="flex items-center gap-3 pb-4 border-b border-slate-50">
                                    <Mail className="h-5 w-5 text-amber-500" />
                                    <h3 className="text-lg font-black text-slate-800 tracking-tight uppercase">Əlaqə Səhifəsi Mətnləri</h3>
                                </div>
                                <div className="space-y-4">
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Əlaqə Başlığı</label>
                                        <input
                                            type="text"
                                            value={formData.contactTitle}
                                            onChange={e => setFormData({ ...formData, contactTitle: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Əlaqə Alt-başlığı</label>
                                        <textarea
                                            rows={2}
                                            value={formData.contactSubtitle}
                                            onChange={e => setFormData({ ...formData, contactSubtitle: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6">
                                <div className="flex items-center gap-3 pb-4 border-b border-slate-50">
                                    <LinkIcon className="h-5 w-5 text-blue-500" />
                                    <h3 className="text-lg font-black text-slate-800 tracking-tight uppercase">CTA (Təklif Al) Bölməsi</h3>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-1.5 md:col-span-2">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">CTA Başlığı</label>
                                        <input
                                            type="text"
                                            value={formData.ctaTitle}
                                            onChange={e => setFormData({ ...formData, ctaTitle: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">CTA Buton Mətni</label>
                                        <input
                                            type="text"
                                            value={formData.ctaButtonText}
                                            onChange={e => setFormData({ ...formData, ctaButtonText: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">CTA Buton Linki</label>
                                        <input
                                            type="text"
                                            value={formData.ctaButtonLink}
                                            onChange={e => setFormData({ ...formData, ctaButtonLink: e.target.value })}
                                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm font-medium"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    <div className="sticky bottom-6 left-0 right-0 z-20">
                        <div className="bg-white/80 backdrop-blur-md p-4 rounded-2xl border border-white shadow-2xl flex justify-end">
                            <button
                                type="submit"
                                className="bg-accent hover:bg-emerald-600 text-white px-12 py-4 rounded-xl font-black text-sm shadow-xl shadow-accent/20 transition-all flex items-center gap-3"
                            >
                                {success ? <Check className="h-5 w-5" /> : <Check className="h-5 w-5" />}
                                {success ? 'Yadda Saxlanıldı!' : 'Dəyişiklikləri Yadda Saxla'}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </AdminLayout>
    );
};

export default SettingsManager;
